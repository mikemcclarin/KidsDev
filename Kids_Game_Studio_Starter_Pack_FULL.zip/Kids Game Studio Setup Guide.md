# 🎮 Kids Game Studio Setup Guide
*(Parent-led, kid-powered)*

Welcome to the **Kids Game Studio**.

You are about to make **real games and apps** that run on real computers and can be shared with real people.

You do **not** need to know how to code yet.
Your job is to:
- Have ideas
- Make choices
- Test things
- Improve them

The computer and AI do the heavy lifting.

---

## 🧠 The Rules
- Browser games and apps only
- No accounts, logins, or chat
- No real names, schools, or locations
- A parent must help publish

---

## 📁 Where Projects Live
All projects live in:
C:\KidsDev

Folders:
- Games
- Apps
- SharedAssets
- StudioSite

---

## 📝 Make a Game Plan
Answer before building:
- Game name
- What do you do?
- How do you win?
- How do you lose?
- Controls
- Art style
- Sound (yes/no)
- One cool idea

---

## 🔁 The Tiny Loop
1. Idea
2. Build
3. Run
4. Change one thing
5. Repeat

---

You are a real game developer. Let's build something awesome.
