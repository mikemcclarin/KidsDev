# 🛠️ Kids Game Studio – Parent Setup Checklist
*(Windows · Web-first · Claude Code CLI)*

## Phase 1: Safety
- [ ] Kids use standard (non-admin) accounts
- [ ] Browsers and Windows updated

## Phase 2: Tools
- [ ] VS Code installed
- [ ] Git installed and verified
- [ ] Node.js (LTS) installed
- [ ] Claude Code CLI installed and verified

## Phase 3: Workspace
- [ ] Create C:\KidsDev
- [ ] Create Games, Apps, SharedAssets, StudioSite
- [ ] Open folder in VS Code

## Phase 4: Guardrails
- [ ] Create prompts.txt with rules
- [ ] Lock editing to parent

## Phase 5: First Game
- [ ] Create ClickerGame folder
- [ ] Add README.md with game brief
- [ ] Generate game with Claude
- [ ] Run index.html

## Phase 6: Teaching
- [ ] Explain Tiny Loop
- [ ] Enforce one change per session
