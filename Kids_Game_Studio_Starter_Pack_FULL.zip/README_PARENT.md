# Parent Notes

This starter pack exists to make setup repeatable and safe.

Parent controls:
- Tool installation
- Claude prompts
- Publishing

Kids control:
- Ideas
- Testing
- Iteration

Finished > Fancy.
